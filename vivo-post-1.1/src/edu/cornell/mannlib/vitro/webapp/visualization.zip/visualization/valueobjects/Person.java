package edu.cornell.mannlib.vitro.webapp.visualization.valueobjects;

import java.util.Set;
import java.util.HashSet;

public class Person extends Individual {

	Set<BiboDocument> documents = new HashSet<BiboDocument>();
	
	public Person(String individualURI) {
		super(individualURI);
	}
	
	public Set<BiboDocument> getDocuments() {
		return documents;
	}

	public Person(String individualURI, String individualLabel) {
		super(individualURI, individualLabel);
	}

}
